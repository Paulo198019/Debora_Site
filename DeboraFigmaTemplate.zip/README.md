# Template Débora Kulczar Advocacia

## Como usar
1. Exporte imagens adicionais do Figma e coloque na pasta `assets/`.
2. Abra `index.html` no navegador para visualizar.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Faça upload de todos os arquivos.
3. Vá em **Settings → Pages**.
4. Selecione:
   - Branch: `main`
   - Pasta: `/root`
5. Salve e aguarde alguns minutos.

## Estrutura
- index.html
- style.css
- assets/logo.png
- assets/profile.jpg
